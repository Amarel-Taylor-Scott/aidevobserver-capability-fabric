# Edge Primitive Catalog

Generated candidate catalog for edge-first graph compilation.

Rows are not promoted truth. Every row is `candidate=true` and `serves_truth=false`.
Promotion requires source refs, implementation, effect audit, fixture receipts, and benchmark evidence.

## Counts

- `primitive_families`: 4576
- `runtime_wrappers`: 14
- `resolved_primitives`: 25344
- `compatibility_edges`: 129888
- `route_templates`: 1760
- `candidate_bundle_examples`: 600

## Files

- `primitive_families.jsonl`: reusable capability families.
- `runtime_wrappers.jsonl`: runtime packaging surfaces.
- `resolved_primitives.jsonl`: family plus wrapper edge contracts.
- `compatibility_edges.jsonl`: direct output-to-input graph edges.
- `route_templates.jsonl`: reusable route skeletons.
- `candidate_bundle_examples.jsonl`: compact planner inputs.
- `manifest.json`: row counts and hashes.

Use `python3 scripts/check_edge_primitive_catalog.py` after generation.
